#creating the database

CREATE DATABASE global_coding_bootcamp;
USE global_coding_bootcamp;

#creating the tables

CREATE TABLE learner(
	learner_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    account_status ENUM('Active', 'Blocked') DEFAULT 'Active',
    subscription_expiry DATE NOT NULL,
    storage_limit INT NOT NULL CHECK(storage_limit > 0)
    );
SELECT* FROM learner;
    
 CREATE TABLE mentor(
	mentor_id INT AUTO_INCREMENT PRIMARY KEY,
    mentor_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    specialization VARCHAR(100)
    );
SELECT*FROM mentor;

CREATE TABLE bootcamp(
	bootcamp_id INT AUTO_INCREMENT PRIMARY KEY,
	title VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL,
    level ENUM('Beginner', 'Intermediate', 'Advanced') NOT NULL,
    capacity_limit INT NOT NULL CHECK(capacity_limit>0),
    mentor_id INT NOT NULL,
    FOREIGN KEY(mentor_id)
    REFERENCES mentor(mentor_id)
    );
SELECT*FROM bootcamp;

CREATE TABLE enrollment(
	enrollment_id INT AUTO_INCREMENT PRIMARY KEY,
    learner_id INT NOT NULL UNIQUE,
    bootcamp_id INT NOT NULL UNIQUE,
    enrollment_date DATE NOT NULL DEFAULT(CURRENT_DATE),
    FOREIGN KEY(learner_id)
    REFERENCES learner(learner_id),
    FOREIGN KEY(bootcamp_id)
    REFERENCES bootcamp(bootcamp_id)
    );
    SELECT*FROM enrollment;
    
    CREATE TABLE module(
		module_id INT AUTO_INCREMENT PRIMARY KEY,
        bootcamp_id INT NOT NULL,
        module_code VARCHAR(50) NOT NULL,
        module_order INT NOT NULL CHECK(module_order > 0),
        
        FOREIGN KEY(bootcamp_id)
        REFERENCES bootcamp(bootcamp_id)
        );
SELECT*FROM module;

CREATE TABLE module_progress(
	progress_id INT AUTO_INCREMENT PRIMARY KEY,
    learner_id INT NOT NULL,
    module_id INT NOT NULL,
    completion_status ENUM('Incomplete', 'In progress', 'Complete') NOT NULL,
    progress_percentage TINYINT NOT NULL CHECK (progress_percentage BETWEEN 0 AND 100),
    skill_points INT DEFAULT 0 CHECK(skill_points >= 0),
    
    FOREIGN KEY(learner_id)
    REFERENCES learner(learner_id),
    FOREIGN KEY(module_id)
    REFERENCES module(module_id)
    );
SELECT*FROM module_progress;

CREATE TABLE assessment(
	assessment_id INT AUTO_INCREMENT PRIMARY KEY,
    bootcamp_id INT NOT NULL,
    assessment_type ENUM('Quiz','Project', 'Exam') NOT NULL,
    title VARCHAR(100) NOT NULL,
    highest_score INT NOT NULL CHECK(highest_score BETWEEN 0 AND 100),
    
    FOREIGN KEY (bootcamp_id)
    REFERENCES bootcamp(bootcamp_id)
    );
SELECT*FROM assessment;

CREATE TABLE assessment_result(
	result_id INT AUTO_INCREMENT PRIMARY KEY,
    assessment_id INT NOT NULL,
    learner_id INT NOT NULL,
    marks_obtained INT NOT NULL CHECK(marks_obtained BETWEEN 0 AND 100),
    skill_score INT NOT NULL CHECK(skill_score >=0),
    
    FOREIGN KEY (assessment_id)
    REFERENCES assessment(assessment_id),
    FOREIGN KEY (learner_id)
    REFERENCES learner(learner_id)
    );
SELECT*FROM assessment_result;

CREATE TABLE resource(
	resource_id INT AUTO_INCREMENT PRIMARY KEY,
    bootcamp_id INT NOT NULL,
    resource_type ENUM('Video', 'PDF', 'Word document') NOT NULL,
    resource_size INT NOT NULL CHECK(resource_size > 0),
    download_count INT DEFAULT 0 CHECK(download_count >=0),
    
    FOREIGN KEY(bootcamp_id)
    REFERENCES bootcamp(bootcamp_id)
    );
SELECT*FROM resource;

CREATE TABLE error_log(
error_id INT AUTO_INCREMENT PRIMARY KEY,
learner_id INT NOT NULL,
error_category VARCHAR(100) NOT NULL,
error_message TEXT NOT NULL,
timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,

FOREIGN KEY(learner_id)
REFERENCES learner(learner_id)
);

SELECT*FROM error_log;

#INSERTING THE SAMPLE DATA
INSERT INTO learner(username, password, account_status, subscription_expiry,storage_limit)
VALUES
('plamplam_dev', 'admin2026', 'Active', '2026-07-29', '500'),
('lumie_light', 'admin207', 'Active', '2026-11-15', '450'),
('destiny_engineer', 'admin478', 'Active', '2026-08-15', '350');
SELECT*FROM learner;

INSERT INTO mentor(mentor_name, email, specialization)
VALUES
('Vuyelwa Mphanda', 'vuyelwa.mphanda@outook.com', 'Software Engineering'),
('Thendo Siphuma', 'thendo.siphuma@outlook.com', 'Data Science'),
('Dr Kevin Patel', 'kevin.patel@outlook.com', 'Web Development');
SELECT*FROM mentor;

INSERT INTO bootcamp(title, category, level, capacity_limit, mentor_id)
VALUES
('Code Platoon', 'Web Development', 'Beginner', '20', '3'),
('Fullstack Software dev bootcamp', 'Software Engineering', 'Intermediate', '25', '1'),
('Data Science Foundations', 'Data Science', 'Advanced', '30', '2');
SELECT*FROM bootcamp;

ALTER TABLE module
MODIFY module_code VARCHAR(50);

INSERT INTO module(bootcamp_id, module_code,module_order)
VALUES
('2', 'ITMDAO11','2'),
('1', 'ITJEAO11', '1'),
('3', 'ITDSAO11','3');

SELECT*FROM module;

INSERT INTO enrollment(learner_id, bootcamp_id, enrollment_date)
VALUES
('1', '2', '2026-02-04'),
('2', '1', '2026-01-15'),
('3', '3', '2026-01-20');

SELECT*FROM enrollment;

INSERT INTO module_progress(learner_id, module_id, completion_status, progress_percentage, skill_points)
VALUES
('1', '1', 'Complete', '100', '80'),
('2', '3', 'In Progress', '50', '40'),
('3', '2', 'Incomplete', '20', '0');

SELECT*FROM module_progress;
SELECT*FROM enrollment;



INSERT INTO assessment_result(assessment_id, learner_id, marks_obtained, skill_score)
VALUES
('1', '1', '67', '40'),
('1', '2', '88', '75'),
('2', '3', '54', '55'),
('3', '4', '93', '67'),
('5', '1', '70', '60');

SELECT*FROM assessment_result;

INSERT INTO assessment_result(assessment_id, learner_id, marks_obtained, skill_score)
VALUES
('11', '1', '67', '40'),
('12', '2', '88', '75'),
('13', '3', '54', '55');

SELECT*FROM assessment;

ALTER TABLE assessment
MODIFY assessment_type ENUM('Quiz', 'Project', 'Coding quiz');

INSERT INTO assessment(bootcamp_id, assessment_type, title, highest_score)
VALUES
('1', 'Quiz', 'Web Basics Quiz', '85'),
('2', 'Quiz', 'MySQL theory', '75' ),
('3', 'Project', 'Mini mobile app', '80');


SELECT*FROM assessment;
SELECT*FROM bootcamp;
SELECT*FROM assessment_result;
SELECT*FROM bootcamp;


INSERT INTO resource(bootcamp_id, resource_type, resource_size, download_count)
VALUES
('1', 'PDF', '10', '5'),
('2', 'Video', '120', '3'),
('3', 'Word document', '15', '4');

SELECT*FROM learner;


INSERT INTO error_log(learner_id, error_category, error_message)
VALUES
('3', 'Login Failure', 'Incorrect password entered'),
('2', 'Payment failure', 'Subscription renewal declined'),
('1', 'System error', 'Failed to upload project');
SELECT*FROM error_log;


CREATE VIEW vwBlockedLearners AS
SELECT
	learner_id,
    username,
    account_status,
    subscription_expiry
FROM learner
WHERE account_status = 'Blocked'
	AND subscription_expiry < CURDATE();
 
 #CREATING THE VIEWS
CREATE VIEW vwTopCoders AS
SELECT
	l.learner_id,
    l.username,
    SUM(ar.skill_score) AS
    total_skill_score
FROM learner l
JOIN assessment_result ar
ON l. learner_id = ar.learner_id
GROUP BY l. learner_id, l.username
ORDER BY total_skill_score DESC
LIMIT 20;

SELECT*FROM vwTopCoders
ORDER BY total_skill_score DESC
LIMIT 20;


CREATE VIEW vwMostDownloadedResources
AS
SELECT 
resource_id,
bootcamp_id,
resource_type,
resource_size,
download_count
FROM resource
ORDER BY download_count DESC
LIMIT 20;

SELECT*FROM vwMostDownloadedResources;

CREATE VIEW vwPoularBootcamps AS 
SELECT 
b.bootcamp_id,
b.title,
COUNT(e.enrollment_id) AS total_enrollments
FROM bootcamp b
LEFT JOIN enrollment e
ON b.bootcamp_id = e.bootcamp_id
GROUP BY b.bootcamp_id, b.title
ORDER BY total_enrollments DESC
LIMIT 5;

SELECT*FROM vwPoularBootcamps;

#CREATING THE STORED PROCEDURES

DELIMITER $$
CREATE PROCEDURE spRegisterLearner(
IN p_username VARCHAR(50),
IN p_password VARCHAR(100),
IN p_subscription_expiry DATE,
IN p_storage_limit INT
)

BEGIN 
IF EXISTS (SELECT 1 FROM learner WHERE username = p_username)
THEN SIGNAL SQLSTATE '45000'
SET MESSAGE_TEXT = 'username already exists';
END IF;

INSERT INTO learner (username, password, account_status, subscription_expiry, storage_limit)
VALUES
(p_username, p_password, 'Active', p_subscription_expiry, p_storage_limit);

END $$

DELIMITER ;

SELECT*FROM learner;

DELIMITER $$

CREATE PROCEDURE spRenewSubscription(
IN p_learner_id INT,
IN p_days INT 
)

BEGIN 
UPDATE learner
SET subscription_expiry = DATE_ADD(subscription_expiry, INTERVAL p_days DAY),
account_status = 'Active'
WHERE learner_id = p_learner_id;
END $$

DELIMITER ;
SELECT*FROM learner;


DELIMITER $$
CREATE PROCEDURE spEnrollLearner(
IN p_learner_id INT,
IN p_bootcamp_id INT 
)
BEGIN 
	DECLARE v_capacity INT;
    DECLARE v_enrolled INT;
    
IF EXISTS(
	SELECT 1 FROM enrollment WHERE learner_id = p_learner_id
    AND bootcamp_id = p_bootcamp_id
)
THEN SIGNAL SQLSTATE '45000'
SET MESSAGE_TEXT = 'Learner already enrolled in this bootcamp';
END IF;

SELECT capacity_limit INTO v_capacity
FROM bootcamp WHERE bootcamp_id = p_bootcamp_id;

SELECT COUNT(*) INTO v_enrolled 
FROM enrollment WHERE bootcamp_id = p_bootcamp_id;

IF v_enrolled >= v_capacity THEN SIGNAL SQLSTATE '45000'
SET MESSAGE_TEXT = 'Bootcamp capacity reached';
END IF;

INSERT INTO enrollment(learner_id, bootcamp_id,enrollment_date)
VALUES
(p_learner_id, p_bootcamp_id, CURDATE());
END $$

DELIMITER ;

DELIMITER $$
CREATE PROCEDURE spAddResource(
IN p_bootcamp_id INT,
IN p_learner_id INT,
IN p_resource_type ENUM ('PDF', 'Video', 'Word document'),
IN p_resource_size INT 
)

BEGIN 
	DECLARE v_max_storage INT;
    DECLARE v_used_storage INT;
    
    SELECT storage_limit INTO v_max_storage
    FROM learner WHERE learner_id = p_learner_id;
    
    SELECT IFNULL((resource_size), 0 )
    INTO v_used_storage
    FROM resource WHERE bootcamp_id IN(
    SELECT bootcamp_id FROM enrollment
    WHERE learner_id = p_learner_id
    );
    
    IF (v_used_storage + p_resource_size) > v_max_storage THEN 
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Storage capacity is full';
    END IF;
    
    INSERT INTO resource(bootcamp_id, resource_type, resource_size, download_count)
    VALUES 
    (p_bootcamp_id, p_resource_type, p_resource_size, 0);
    END$$
    
    DELIMITER ;
    
    CALL spAddResource('1', '1', 'PDF', '5');
SELECT*FROM resource;

DELIMITER $$
CREATE PROCEDURE spSendNotice()
BEGIN 
SELECT learner_id,
		username, 
        subscription_expiry,
        
	DATEDIFF(subscription_expiry, curdate()) AS outstanding_days From learner;
    END $$
 
 DELIMITER ;
 
 
#CREATING TRIGGERS
#THIS TRIGGER BLOCKS LEARNERS FROM ACCESSING THEIR ACCOUNTS WHEN IT IS BEING UPDATED 

DELIMITER $$
CREATE TRIGGER 
trg_block_expired_subscription 
BEFORE UPDATE ON learner
FOR EACH ROW 
BEGIN 
IF NEW.subscription_expiry < CURDATE() THEN
SET NEW.account_status = 'Blocked';
END IF;
END $$

DELIMITER ;


#THIS TRIGGER BLOCKS LEARNERS WHENEVER THEIR SUBSCRIPTION EXPIRY CHANGES
DELIMITER $$

CREATE TRIGGER
trg_block_expired_account
BEFORE UPDATE ON learner
FOR EACH ROW 
BEGIN
IF NEW.subscription_expiry < CURDATE() THEN
SET NEW.account_status = 'Blocked';
END IF;
END$$

DELIMITER ;

#THIS TRIGGER PREVENTS LEARNERS WHO HAVE AN EXPIRED SUBSCRIPTION FROM LOGGING IN
DELIMITER $$

CREATE TRIGGER
trg_log_error
AFTER INSERT ON enrollment
FOR EACH ROW 
BEGIN
	DECLARE v_capacity INT;
    DECLARE v_enrolled INT;
    
    SELECT capacity_limit INTO v_capacity
    FROM bootcamp WHERE bootcamp_id = NEW.bootcamp_id;
    
    SELECT COUNT(*) INTO v_enrolled FROM enrollment
    WHERE bootcamp_id = NEW.bootcamp_id;
    
    IF v_enrolled > v_capacity THEN INSERT INTO error_log(learner_id, error_category, error_message)
    VALUES
    (NEW.learner_id, 'Enrollment Error', 'Reached full capacity');
    END IF;
    
    END $$
    
    DELIMITER ;

DELIMITER $$
CREATE TRIGGER 
trg_login_failure
AFTER UPDATE ON learner 
FOR EACH ROW 
BEGIN 
IF NEW.account_status = 'Blocked'
AND OLD.account_status = 'Active' THEN 
INSERT INTO error_log(learner_id, error_category, error_message)
VALUES
(NEW.learner_id, 'Login failure', 'Account blocked due to expired subscription!');
END IF;
END $$

DELIMITER ;

#CREATING THE INDEXES
#INDEXES FOR FASTER LOOKUPS ON LEARNERS, BOOTCAMPS AND ENROLLMENTS

#A FSTER LOOKUP FOR LEARNERS BY USERNAME OR ACCOUNT STATUS
CREATE INDEX idx_learner_username
ON learner(username);


CREATE INDEX idx_learner_status
ON learner(account_status);


#A FASTER LOOKUP FOR BOOTCAMP MENTORS AND LEVELS
CREATE INDEX idx_bootcamp_mentor
ON bootcamp(mentor_id);

CREATE INDEX idx_bootcamp_level
ON bootcamp(level);


#A FASTER LOOKUP FOR A LEARNER AND ENROLLMENTS PER BOOTCAMP
CREATE INDEX idx_enrollment_learner
ON enrollment(learner_id);

CREATE INDEX idx_enrollment_bootcamp
ON enrollment(bootcamp_id);



